'''
===============================================================================
Creator: Christopher Sabater Cordero
Original: Nguyen Ha Dong
Date Started: 12/30/2015
File: Flappy Bird Clone
Notice: (c) Copyright 2015 by Christopher Sabater Cordero  All Rights Reserved.
===============================================================================
'''